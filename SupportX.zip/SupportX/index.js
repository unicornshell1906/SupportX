require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');
const fs = require('fs');
const path = require('path');
const database = require('./database');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message]
});

client.commands = new Collection();
client.database = database;

const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
        }
    }
}

const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    }
}

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
    console.error('❌ DISCORD_BOT_TOKEN is not set in environment variables!');
    console.log('\n📝 To set your bot token:');
    console.log('1. Go to https://discord.com/developers/applications');
    console.log('2. Create or select your bot application');
    console.log('3. Go to the Bot tab and copy your token');
    console.log('4. Set the DISCORD_BOT_TOKEN environment variable in Replit Secrets\n');
    process.exit(1);
}

console.log('🔐 Token found, attempting to connect...');
console.log(`📊 Token length: ${token.length} characters`);

client.login(token).catch(error => {
    console.error('❌ Failed to login:', error.message);
    console.log('\n🔧 Common fixes:');
    console.log('1. Go to Discord Developer Portal → Your App → Bot');
    console.log('2. Click "Reset Token" to generate a NEW token');
    console.log('3. Copy the new token immediately');
    console.log('4. Update DISCORD_BOT_TOKEN in Replit Secrets with the new token');
    console.log('5. Make sure these intents are enabled:');
    console.log('   - SERVER MEMBERS INTENT');
    console.log('   - MESSAGE CONTENT INTENT\n');
    process.exit(1);
});

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});
